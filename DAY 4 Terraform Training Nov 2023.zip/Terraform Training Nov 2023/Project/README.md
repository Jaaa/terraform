Project

Createing an Ec2 in a custom VPC

Create VPC and Network  - -1 module
Create SG - 1 module
Create Ec2 - 1 module

FUNCTIONS
* count, lifecycle, depends_on[] (meta-argument)
* conditional expression
   condition ? true : false

* length()
* merge  ==> multiple maps variables and it will merge into 1 single map
* format

* terraform state mv source destination

* for_each
* dynamic


map ==> is a collection of key-value pairs (similar data type)

object