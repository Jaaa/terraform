*.tf
terraform.tfvars
gokul.auto.tfvars
.tfvars.json

Dependencies
* implicit (terraform auto understand)
* explicit (worst case scenario)


* terraform init
    * Initialise **root level files** in the current folder
    * provider (download the latest version)
    * backend (if block exist)
    * modules (if module block exist)


resource "<type>" "<ref_name>" {
    # ARGUMENTs
    * required 
    * optional
    * optional (default)
}
# <type>.<ref_name>